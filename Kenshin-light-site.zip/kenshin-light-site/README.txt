LIGHTWEIGHT RURouni KENSHIN FAN SITE

Files:
  index.html
  style.css
  assets/kenshin.webp
  assets/kaoru.webp
  assets/hero.webp

The page has no external CSS/JS frameworks. Images are local WebP files for easy EC2 hosting.

Apache example:
  sudo cp -r kenshin-light-site/* /var/www/html/
  sudo systemctl restart apache2

Then open:
  http://YOUR-EC2-PUBLIC-IP/
